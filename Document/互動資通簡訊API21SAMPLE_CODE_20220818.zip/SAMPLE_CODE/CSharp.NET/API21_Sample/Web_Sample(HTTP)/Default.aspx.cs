﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace Web_Sample_HTTP_ {
	public partial class _Default : System.Web.UI.Page {
		protected void Page_Load(object sender, EventArgs e) {

		}

		protected void btnSend_Click(object sender, EventArgs e) {
			SMSHttp smsHttp = new SMSHttp();
            if (smsHttp.sendSMS(accountInputText.Value, passwordInputText.Value, subjectInputText.Value, msgText.Value, paramText.Value, phonesInputText.Value, "", attachmentTextarea.Value, typeText.Value, isParam.Checked, isPersonal.Checked, isMMS.Checked)) {
                Page.Controls.Add(new LiteralControl(new StringBuilder("<script>alert('發送成功！點數剩餘").Append(smsHttp.Credit).Append("點。（").Append(smsHttp.ProcessMsg).Append("）');</script>").ToString()));
			} else {
                Page.Controls.Add(new LiteralControl("<script>alert('發送失敗！錯誤訊息：" + smsHttp.ProcessMsg + "');" + "</script>"));
			}
		}
	}
}
