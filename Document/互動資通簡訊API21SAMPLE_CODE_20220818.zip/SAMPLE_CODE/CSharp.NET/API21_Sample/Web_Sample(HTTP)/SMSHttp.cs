﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;

namespace Web_Sample_HTTP_ {
    public class SMSHttp {
        private string sendSMSUrl = "https://api.e8d.tw/API21/HTTP/sendSMS.ashx";
        private string sendParamSMSUrl = "https://api.e8d.tw/API21/HTTP/SendParamSMS.ashx";
        private string sendMMSUrl = "https://api.e8d.tw/API21/HTTP/MMS/sendMMS.ashx";
        private string getCreditUrl = "https://api.e8d.tw/API21/HTTP/getCredit.ashx";
        private string processMsg = "";
        private string batchID = "";
        private double credit = 0;

        public SMSHttp() {
        }

        /// <summary>
        /// 傳送簡訊
        /// </summary>
        /// <param name="userID">帳號</param>
        /// <param name="password">密碼</param>
        /// <param name="subject">簡訊主旨，主旨不會隨著簡訊內容發送出去。用以註記本次發送之用途。可傳入空字串。</param>
        /// <param name="content">簡訊發送內容(SMS一般、SMS參數、MMS一般簡訊需填寫)</param>
        /// <param name="param">簡訊Param內容(參數、個人化(專屬)簡訊需填寫Json格式)</param>
        /// <param name="mobile">接收人之手機號碼。格式為: +886900000001。多筆接收人時，請以半形逗點隔開( , )，如+886900000001,+886900000002。</param>
        /// <param name="sendTime">簡訊預定發送時間。-立即發送：請傳入空字串。-預約發送：請傳入預計發送時間，若傳送時間小於系統接單時間，將不予傳送。格式為YYYYMMDDhhmnss；例如:預約2009/01/31 15:30:00發送，則傳入20090131153000。若傳遞時間已逾現在之時間，將立即發送。</param>
        /// <param name="attachment">image base64</param>
        /// <param name="type">圖檔副檔名</param>
        /// <param name="isParam">是否為SMS參數簡訊</param>
        /// <param name="isPersonal">是否為SMS個人化(專屬)簡訊</param>
        /// <param name="isMMS">是否為MMS一般簡訊</param>
        /// <returns>true:傳送成功；false:傳送失敗</returns>
        public bool sendSMS(string userID, string password, string subject, string content, string param, string mobile, string sendTime, string attachment, string type, bool isParam, bool isPersonal, bool isMMS) {
            bool success = false;
            StringBuilder postDataSb = new StringBuilder();
            string resultString = string.Empty;
            string[] split = null;

            try {
                #region UrlEncode
                subject = !isParam && !isPersonal ? HttpUtility.UrlEncode(subject) : subject;
                content = !isParam && !isPersonal ? HttpUtility.UrlEncode(content) : content;
                mobile = !isParam && !isPersonal ? HttpUtility.UrlEncode(mobile) : mobile;
                attachment = isMMS ? HttpUtility.UrlEncode(attachment) : attachment;
                #endregion

                #region 檢查時間格式
                if (!string.IsNullOrEmpty(sendTime)) {
                    try {
                        //檢查傳送時間格式是否正確
                        DateTime checkDt = DateTime.ParseExact(sendTime, "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
                        if (!sendTime.Equals(checkDt.ToString("yyyyMMddHHmmss"))) {
                            processMsg = "傳送時間格式錯誤";
                            return success;
                        }
                    } catch {
                        processMsg = "傳送時間格式錯誤";
                        return success;
                    }
                }
                #endregion

                #region SMS一般簡訊
                if (!isParam && !isPersonal && !isMMS) {
                    postDataSb.Append("UID=").Append(userID);
                    postDataSb.Append("&PWD=").Append(password);
                    postDataSb.Append("&SB=").Append(subject);
                    postDataSb.Append("&MSG=").Append(content);
                    postDataSb.Append("&DEST=").Append(mobile);
                    postDataSb.Append("&ST=").Append(sendTime);
                    resultString = httpPost(sendSMSUrl, postDataSb.ToString(), false);
                }
                #endregion

                #region SMS參數簡訊
                if (isParam) {
                    //「發送內容」範例(msg)：測試%field1%%field2%
                    //「Param內容」範例(param)：[{"Name":"test_A","Mobile":"+886900000001","Email":"testA@test.com.tw","SendTime":"29990109083000","Param":"A1|A2|||"},{"Name":"test_B","Mobile":"+886900000002","Email":"testB@test.com.tw","SendTime":"29990125173000","Param":"B1|B2|||"}]
                    postDataSb.Append("{\"UID\":\"").Append(userID).Append("\",");
                    postDataSb.Append("\"PWD\":\"").Append(password).Append("\",");
                    postDataSb.Append("\"SB\":\"").Append(subject).Append("\",");
                    postDataSb.Append("\"MSG\":\"").Append(content).Append("\",");
                    postDataSb.Append("\"RecipientDataList\":").Append(param).Append("}");
                    resultString = httpPost(sendParamSMSUrl, postDataSb.ToString(), isParam);
                }
                #endregion

                #region SMS個人化(專屬)簡訊
                if (isPersonal) {
                    //「Param內容」範例(param)：[{"Name":"test_A","Mobile":"+886900000001","Email":"testA@test.com.tw","SendTime":"29990109083000","Param":"測試A1A2"},{"Name":"test_B","Mobile":"+886900000002","Email":"testB@test.com.tw","SendTime":"29990125173000","Param":"測試B1B2"}]
                    postDataSb.Append("{\"UID\":\"").Append(userID).Append("\",");
                    postDataSb.Append("\"PWD\":\"").Append(password).Append("\",");
                    postDataSb.Append("\"SB\":\"").Append(subject).Append("\",");
                    postDataSb.Append("\"RecipientDataList\":").Append(param).Append("}");
                    resultString = httpPost(sendParamSMSUrl, postDataSb.ToString(), isPersonal);
                }
                #endregion

                #region MMS一般簡訊
                if (isMMS) {
                    postDataSb.Append("UID=").Append(userID);
                    postDataSb.Append("&PWD=").Append(password);
                    postDataSb.Append("&SB=").Append(subject);
                    postDataSb.Append("&MSG=").Append(content);
                    postDataSb.Append("&DEST=").Append(mobile);
                    postDataSb.Append("&ST=").Append(sendTime);
                    postDataSb.Append("&ATTACHMENT=").Append(attachment);
                    postDataSb.Append("&TYPE=").Append(type);
                    resultString = httpPost(sendMMSUrl, postDataSb.ToString(), false);
                }
                #endregion

                processMsg = resultString;

                #region SMS、MMS一般簡訊發送結果
                if (!isParam && !isPersonal && !resultString.StartsWith("-")) {
                    /* 
                     * 傳送成功 回傳字串內容格式為：CREDIT,SENDED,COST,UNSEND,BATCH_ID，各值中間以逗號分隔。
                     * CREDIT：發送後剩餘點數。負值代表發送失敗，系統無法處理該命令
                     * SENDED：發送通數。
                     * COST：本次發送扣除點數
                     * UNSEND：無額度時發送的通數，當該值大於0而剩餘點數等於0時表示有部份的簡訊因無額度而無法被發送。
                     * BATCH_ID：批次識別代碼。為一唯一識別碼，可藉由本識別碼查詢發送狀態。格式範例：220478cc-8506-49b2-93b7-2505f651c12e
                     */
                    split = resultString.Split(',');
                    credit = Convert.ToDouble(split[0]);
                    batchID = split[4];
                    return success = true;
                }
                #endregion

                #region SMS參數、個人化(專屬)簡訊發送結果
                if ((isParam || isPersonal) && resultString.Contains("true")) {
                    /* 
                     * 傳送成功 回傳字串內容格式為：{"Result":true,"Status":"0","Msg":"CREDIT,SENDED,COST,UNSEND,BATCH_ID"}
                     * CREDIT：發送後剩餘點數。負值代表發送失敗，系統無法處理該命令
                     * SENDED：發送通數。
                     * COST：本次發送扣除點數
                     * UNSEND：無額度時發送的通數，當該值大於0而剩餘點數等於0時表示有部份的簡訊因無額度而無法被發送。
                     * BATCH_ID：批次識別代碼。為一唯一識別碼，可藉由本識別碼查詢發送狀態。格式範例：220478cc-8506-49b2-93b7-2505f651c12e
                     */
                    int s = resultString.IndexOf("Msg") + 6;
                    int e = resultString.Length - 2;
                    split = resultString.Substring(s, e - s).Split(',');
                    credit = Convert.ToDouble(split[0]);
                    batchID = split[4];
                    return success = true;
                }
                #endregion

                //傳送失敗
                processMsg = resultString;

            } catch (Exception ex) {
                processMsg = ex.ToString();
            }
            return success;
        }

        /// <summary>
        /// 取得帳號餘額
        /// </summary>
        /// <returns>true:取得成功；false:取得失敗</returns>
        public bool getCredit(string userID, string password) {
            bool success = false;
            try {
                StringBuilder postDataSb = new StringBuilder();
                postDataSb.Append("UID=").Append(userID);
                postDataSb.Append("&PWD=").Append(password);

                string resultString = httpPost(getCreditUrl, postDataSb.ToString(), false);
                if (!resultString.StartsWith("-")) {
                    credit = Convert.ToDouble(resultString);
                    success = true;
                } else {
                    processMsg = resultString;
                }
            } catch (Exception ex) {
                processMsg = ex.ToString();
            }
            return success;
        }

        private string httpPost(string url, string postData, bool isSendParamSMS) {
            string result = "";
            try {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(url));
                request.Method = "POST";
                if (!isSendParamSMS) {
                    request.ContentType = "application/x-www-form-urlencoded";
                } else {
                    request.ContentType = "application/json";                
                }
                byte[] bs = System.Text.Encoding.UTF8.GetBytes(postData);
                request.ContentLength = bs.Length;
                request.GetRequestStream().Write(bs, 0, bs.Length);
                //取得 WebResponse 的物件 然後把回傳的資料讀出
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader sr = new StreamReader(response.GetResponseStream());
                result = sr.ReadToEnd();
            } catch (Exception ex) {
                processMsg = ex.ToString();
            }
            return result;
        }

        public string ProcessMsg {
            get {
                return processMsg;
            }
        }

        public string BatchID {
            get {
                return batchID;
            }
        }

        public double Credit {
            get {
                return credit;
            }
        }
    }
}