﻿Imports System.Net
Imports System.IO
Imports System.Text

Public Class SMSHttp
    Private sendSMSUrl As String = "https://api.e8d.tw/API21/HTTP/sendSMS.ashx"
    Private sendParamSMSUrl As String = "https://api.e8d.tw/API21/HTTP/SendParamSMS.ashx"
    Private sendMMSUrl As String = "https://api.e8d.tw/API21/HTTP/MMS/sendMMS.ashx" '
    Private getCreditUrl As String = "https://api.e8d.tw/API21/HTTP/getCredit.ashx"
    Private batchID As String
    Private credit As Double
    Private processMsg As String

    Public Sub New()

    End Sub

    ''' <summary>
    ''' 傳送簡訊
    ''' </summary>
    ''' <param name="userID">帳號</param>
    ''' <param name="password">密碼</param>
    ''' <param name="subject">簡訊主旨，主旨不會隨著簡訊內容發送出去。用以註記本次發送之用途。可傳入空字串。</param>
    ''' <param name="msg">簡訊發送內容(SMS一般、SMS參數、MMS一般簡訊需填寫)</param>
    ''' <param name="param">簡訊Param內容(參數、個人化(專屬)簡訊需填寫Json格式)</param>
    ''' <param name="mobile">接收人之手機號碼。格式為: +886900000001。多筆接收人時，請以半形逗點隔開( , )，如+886900000001,+886900000002。</param>
    ''' <param name="sendTime">簡訊預定發送時間。-立即發送：請傳入空字串。-預約發送：請傳入預計發送時間，若傳送時間小於系統接單時間，將不予傳送。格式為YYYYMMDDhhmnss；例如:預約2009/01/31 15:30:00發送，則傳入20090131153000。若傳遞時間已逾現在之時間，將立即發送。</param>
    ''' <param name="attachment">image base64</param>
    ''' <param name="type">圖檔副檔名</param>
    ''' <param name="isParam">是否為SMS參數簡訊</param>
    ''' <param name="isPersonal">是否為SMS個人化(專屬)簡訊</param>
    ''' <param name="isMMS">是否為MMS一般簡訊</param>
    ''' <returns>true:傳送成功；false:傳送失敗</returns>
    ''' <remarks></remarks>
    Public Function sendSMS(ByVal userID As String, ByVal password As String, ByVal subject As String, ByVal msg As String, ByVal param As String, ByVal mobile As String, ByVal sendTime As String, ByVal attachment As String, ByVal type As String, ByVal isParam As Boolean, ByVal isPersonal As Boolean, ByVal isMMS As Boolean) As Boolean
        Dim success As Boolean = False
        Dim resultString As String = ""
        Dim split() As String

        Try
            ''UrlEncode
            If Not isParam And Not isPersonal Then
                subject = HttpUtility.UrlEncode(subject)
                msg = HttpUtility.UrlEncode(msg)
                mobile = HttpUtility.UrlEncode(mobile)
            End If

            If isMMS Then
                attachment = HttpUtility.UrlEncode(attachment)
            End If

            ''檢查時間格式
            If Not String.IsNullOrEmpty(sendTime) Then
                Try
                    Dim checkDt As DateTime = DateTime.ParseExact(sendTime, "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture)
                    If Not sendTime.Equals(checkDt.ToString("yyyyMMddHHmmss")) Then
                        processMsg = "傳送時間格式錯誤"
                        Return success
                    End If
                Catch ex As Exception
                    processMsg = "傳送時間格式錯誤"
                    Return success
                End Try
            End If

            Dim postDataSb As StringBuilder = New StringBuilder()

            ''SMS一般簡訊
            If Not isParam And Not isPersonal And Not isMMS Then
                postDataSb.Append("UID=").Append(userID)
                postDataSb.Append("&PWD=").Append(password)
                postDataSb.Append("&SB=").Append(subject)
                postDataSb.Append("&MSG=").Append(msg)
                postDataSb.Append("&DEST=").Append(mobile)
                postDataSb.Append("&ST=").Append(sendTime)
                resultString = httpPost(sendSMSUrl, postDataSb.ToString())
            End If

            ''SMS參數簡訊
            If isParam Then
                ''「發送內容」範例(msg)：測試%field1%%field2%
                ''「Param內容」範例(param)：[{"Name":"test_A","Mobile":"+886900000001","Email":"testA@test.com.tw","SendTime":"29990109083000","Param":"A1|A2|||"},{"Name":"test_B","Mobile":"+886900000002","Email":"testB@test.com.tw","SendTime":"29990125173000","Param":"B1|B2|||"}]
                postDataSb.Append("{""UID"":""").Append(userID).Append(""",")
                postDataSb.Append("""PWD"":""").Append(password).Append(""",")
                postDataSb.Append("""SB"":""").Append(subject).Append(""",")
                postDataSb.Append("""MSG"":""").Append(msg).Append(""",")
                postDataSb.Append("""RecipientDataList"":").Append(param).Append("}")
                resultString = httpPost(sendParamSMSUrl, postDataSb.ToString(), isParam)
            End If

            ''SMS個人化(專屬)簡訊
            If isPersonal Then
                ''「Param內容」範例(param)：[{"Name":"test_A","Mobile":"+886900000001","Email":"testA@test.com.tw","SendTime":"29990109083000","Param":"測試A1A2"},{"Name":"test_B","Mobile":"+886900000002","Email":"testB@test.com.tw","SendTime":"29990125173000","Param":"測試B1B2"}]
                postDataSb.Append("{""UID"":""").Append(userID).Append(""",")
                postDataSb.Append("""PWD"":""").Append(password).Append(""",")
                postDataSb.Append("""SB"":""").Append(subject).Append(""",")
                postDataSb.Append("""RecipientDataList"":").Append(param).Append("}")
                resultString = httpPost(sendParamSMSUrl, postDataSb.ToString(), isPersonal)
            End If

            ''MMS一般簡訊
            If isMMS Then
                postDataSb.Append("UID=").Append(userID)
                postDataSb.Append("&PWD=").Append(password)
                postDataSb.Append("&SB=").Append(subject)
                postDataSb.Append("&MSG=").Append(msg)
                postDataSb.Append("&DEST=").Append(mobile)
                postDataSb.Append("&ST=").Append(sendTime)
                postDataSb.Append("&ATTACHMENT=").Append(attachment)
                postDataSb.Append("&TYPE=").Append(type)
                resultString = httpPost(sendMMSUrl, postDataSb.ToString())
            End If

            processMsg = resultString

            ''SMS、MMS一般簡訊發送結果
            If Not isParam And Not isPersonal And Not resultString.StartsWith("-") Then
                ''傳送成功 回傳字串內容格式為：CREDIT,SENDED,COST,UNSEND,BATCH_ID，各值中間以逗號分隔。
                '' CREDIT：發送後剩餘點數。負值代表發送失敗，系統無法處理該命令
                '' SENDED：發送通數。
                '' COST：本次發送扣除點數
                '' UNSEND：無額度時發送的通數，當該值大於0而剩餘點數等於0時表示有部份的簡訊因無額度而無法被發送。
                '' BATCH_ID：批次識別代碼。為一唯一識別碼，可藉由本識別碼查詢發送狀態。格式範例：220478cc-8506-49b2-93b7-2505f651c12e
                split = resultString.Split(",")
                credit = Convert.ToDouble(split(0))
                batchID = split(4)
                success = True
                Return success
            End If

            ''SMS參數、個人化(專屬)簡訊發送結果
            If (isParam Or isPersonal) And resultString.Contains("true") Then
                ''傳送成功 回傳字串內容格式為：{"Result":true,"Status":"0","Msg":"CREDIT,SENDED,COST,UNSEND,BATCH_ID"}
                '' CREDIT：發送後剩餘點數。負值代表發送失敗，系統無法處理該命令
                '' SENDED：發送通數。
                '' COST：本次發送扣除點數
                '' UNSEND：無額度時發送的通數，當該值大於0而剩餘點數等於0時表示有部份的簡訊因無額度而無法被發送。
                '' BATCH_ID：批次識別代碼。為一唯一識別碼，可藉由本識別碼查詢發送狀態。格式範例：220478cc-8506-49b2-93b7-2505f651c12e
                Dim s As Integer = resultString.IndexOf("Msg"":""") + 6
                Dim e As Integer = resultString.Length - 2
                split = resultString.Substring(s, e - s).Split(",")
                credit = Convert.ToDouble(split(0))
                batchID = split(4)
                success = True
                Return success
            End If
            ''傳送失敗
            processMsg = resultString
        Catch ex As Exception
            processMsg = ex.ToString()
        End Try
        Return success
    End Function

    ''' <summary>
    ''' 取得帳號餘額
    ''' </summary>
    ''' <param name="userID">帳號</param>
    ''' <param name="password">密碼</param>
    ''' <returns>true:取得成功；false:取得失敗</returns>
    ''' <remarks></remarks>
    Public Function getCredit(ByVal userID As String, ByVal password As String) As Boolean
        Dim success As Boolean = False
        Try
            Dim postDataSb As StringBuilder = New StringBuilder()
            postDataSb.Append("UID=").Append(userID)
            postDataSb.Append("&PWD=").Append(password)

            Dim resultString As String = httpPost(getCreditUrl, postDataSb.ToString())
            If Not resultString.StartsWith("-") Then
                credit = Convert.ToDouble(resultString)
                success = True
            Else
                processMsg = resultString
            End If
        Catch ex As Exception
            processMsg = ex.ToString()
        End Try
        Return success
    End Function

    Private Function httpPost(ByVal url As String, ByVal postData As String, Optional ByVal isSendParamSMS As Boolean = False) As String
        Dim result As String = ""
        Try
            Dim request As HttpWebRequest = CType(WebRequest.Create(New Uri(url)), HttpWebRequest)
            request.Method = "POST"
            If Not isSendParamSMS Then
                request.ContentType = "application/x-www-form-urlencoded"
            Else
                request.ContentType = "application/json"
            End If
            Dim bs() As Byte = System.Text.Encoding.UTF8.GetBytes(postData)
            request.ContentLength = bs.Length
            request.GetRequestStream().Write(bs, 0, bs.Length)
            ''取得 WebResponse 的物件 然後把回傳的資料讀出
            Dim response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)
            Dim sr As StreamReader = New StreamReader(response.GetResponseStream())
            result = sr.ReadToEnd()
        Catch ex As Exception
            processMsg = ex.ToString()
        End Try
        Return result
    End Function

    Public Function getProcessMsg() As String
        Return processMsg
    End Function

    Public Function getBatchID() As String
        Return batchID
    End Function

    Public Function getCreditValue() As Double
        Return credit
    End Function

End Class
